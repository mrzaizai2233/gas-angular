$(function () {
    $('.mix-grid').mixItUp();
});