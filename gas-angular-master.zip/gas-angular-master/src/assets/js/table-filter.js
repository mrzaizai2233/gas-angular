$(function () {
    //BEGIN JQUERY DATE PICKER
    $('.datepicker-filter').datepicker({
        autoclose: true
    });
    //END JQUERY DATE PICKER
});


