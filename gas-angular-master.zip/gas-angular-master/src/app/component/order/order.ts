export interface myEvent {
    target:{
        value?:any
    }
}
export interface product {
    _id:'',
    name:'',
    price
}